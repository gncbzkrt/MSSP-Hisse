plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mssp.personal"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mssp.personal"
        minSdk = 26
        targetSdk = 35
        versionCode = 31001
        versionName = "3.1-github-signed"
    }

    signingConfigs {
        create("release") {
            storeFile = rootProject.file("signing/mssp-personal.jks")
            storePassword = "MSSP_PERSONAL_2026_GITHUB"
            keyAlias = "mssp-personal"
            keyPassword = "MSSP_PERSONAL_2026_GITHUB"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.10.1")
}
