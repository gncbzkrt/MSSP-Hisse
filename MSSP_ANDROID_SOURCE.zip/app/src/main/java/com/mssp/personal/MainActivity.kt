package com.mssp.personal

import android.annotation.SuppressLint
import android.app.Activity
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var pendingBackupJson: String? = null
    private val executor = Executors.newCachedThreadPool()

    companion object {
        private const val REQ_CREATE_BACKUP = 1201
        private const val REQ_OPEN_BACKUP = 1202
        private const val PREFS = "mssp_personal"
        private const val PREF_BACKUP_URI = "backup_uri"
        private const val JOB_ID = 905601
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            loadsImagesAutomatically = true
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = false
            displayZoomControls = false
            userAgentString = "$userAgentString MSSP-PERSONAL-ANDROID/1.0-PARITY"
        }
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false
        }
        webView.addJavascriptInterface(NativeBridge(this), "Android")
        webView.loadUrl("file:///android_asset/index.html")
        scheduleBackgroundUpdate()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    private fun scheduleBackgroundUpdate() {
        try {
            val scheduler = getSystemService(JobScheduler::class.java)
            val component = ComponentName(this, MarketUpdateJobService::class.java)
            val info = JobInfo.Builder(JOB_ID, component)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setPeriodic(6L * 60L * 60L * 1000L)
                .build()
            scheduler.schedule(info)
        } catch (_: Exception) {}
    }

    inner class NativeBridge(private val ctx: Context) {
        @JavascriptInterface
        fun requestHistory(symbol: String, range: String, interval: String, requestId: String) {
            executor.execute {
                val safeSymbol = symbol.trim().uppercase().removePrefix("BIST:").removeSuffix(".IS")
                val yahooSymbol = if (safeSymbol.startsWith("^")) safeSymbol else "$safeSymbol.IS"
                val safeRange = range.ifBlank { "2y" }
                val safeInterval = interval.ifBlank { "1d" }
                var payload = ""
                var error: String? = null
                for (host in listOf("query1.finance.yahoo.com", "query2.finance.yahoo.com")) {
                    try {
                        val url = "https://$host/v8/finance/chart/${Uri.encode(yahooSymbol)}?range=${Uri.encode(safeRange)}&interval=${Uri.encode(safeInterval)}&includePrePost=false&events=div%2Csplits"
                        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                            connectTimeout = 12000; readTimeout = 18000; requestMethod = "GET"
                            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 MSSP-Personal/1.0")
                            setRequestProperty("Accept", "application/json,text/plain,*/*")
                            setRequestProperty("Referer", "https://finance.yahoo.com/")
                        }
                        val code = conn.responseCode
                        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                        val body = BufferedReader(InputStreamReader(stream)).use { it.readText() }
                        conn.disconnect()
                        if (code in 200..299 && body.contains("\"chart\"") && body.contains("\"result\"")) { payload = body; error = null; break }
                        error = "HTTP $code"
                    } catch (e: Exception) { error = e.message ?: e.javaClass.simpleName }
                }
                if (error == null && payload.isNotBlank()) MarketCache.write(ctx, safeSymbol, payload)
                sendJsResult("onHistory", requestId, safeSymbol, payload, error)
            }
        }

        @JavascriptInterface
        fun requestUniverse(requestId: String) {
            executor.execute {
                var payload = ""
                var error: String? = null
                try {
                    val columns = listOf(
                        "name","description","close","change","volume",
                        "relative_volume_10d_calc","RSI","ADX","ATR",
                        "EMA8","EMA21","EMA30",
                        "close|1","close|2","close|3","close|4","close|5",
                        "close|6","close|7","close|8","close|9","close|10",
                        "close|11","close|12","close|13","close|14","close|15",
                        "close|16","close|17","close|18","close|19","close|20",
                        "EMA8|1","EMA21|1",
                        "EMA30|1","EMA30|2","EMA30|3","EMA30|4","EMA30|5"
                    )
                    val root = JSONObject()
                    root.put("symbols", JSONObject().apply {
                        put("query", JSONObject().apply { put("types", org.json.JSONArray()) })
                        put("tickers", org.json.JSONArray())
                    })
                    root.put("options", JSONObject().apply { put("lang", "tr") })
                    root.put("columns", org.json.JSONArray(columns))
                    root.put("range", org.json.JSONArray(listOf(0, 1000)))
                    root.put("sort", JSONObject().apply {
                        put("sortBy", "volume")
                        put("sortOrder", "desc")
                    })
                    val body = root.toString()
                    val conn = (URL("https://scanner.tradingview.com/turkey/scan").openConnection() as HttpURLConnection).apply {
                        connectTimeout = 15000
                        readTimeout = 30000
                        requestMethod = "POST"
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json")
                        setRequestProperty("Accept", "application/json")
                        setRequestProperty("User-Agent", "Mozilla/5.0")
                        setRequestProperty("Origin", "https://www.tradingview.com")
                        setRequestProperty("Referer", "https://www.tradingview.com/")
                    }
                    conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    payload = if (stream != null) BufferedReader(InputStreamReader(stream)).use { it.readText() } else ""
                    if (code !in 200..299) error = "HTTP $code: ${payload.take(180)}"
                    conn.disconnect()
                } catch (e: Exception) { error = e.message ?: e.javaClass.simpleName }
                sendJsResult("onUniverse", requestId, "BIST", payload, error)
            }
        }

        private fun sendJsResult(callback: String, requestId: String, symbol: String, payload: String, error: String?) {
            val response = JSONObject().apply {
                put("requestId", requestId)
                put("symbol", symbol)
                put("ok", error == null && payload.isNotBlank())
                put("payload", payload)
                put("error", error ?: JSONObject.NULL)
            }.toString()
            runOnUiThread {
                webView.evaluateJavascript("window.MSSP_NATIVE && window.MSSP_NATIVE.$callback(${JSONObject.quote(response)});", null)
            }
        }

        @JavascriptInterface fun getCachedHistory(symbol: String): String {
            val safe = symbol.trim().uppercase().removePrefix("BIST:").removeSuffix(".IS")
            return MarketCache.read(ctx, safe) ?: ""
        }
        @JavascriptInterface fun saveWatchlist(json: String) { getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("watchlist", json).apply() }
        @JavascriptInterface fun getWatchlist(): String = getSharedPreferences(PREFS, MODE_PRIVATE).getString("watchlist", "") ?: ""
        @JavascriptInterface fun getLastAutoUpdate(): String = getSharedPreferences(PREFS, MODE_PRIVATE).getString("last_auto_update", "") ?: ""
        @JavascriptInterface fun requestBackup(json: String) {
            pendingBackupJson = json
            runOnUiThread {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "MSSP_PERSONAL_YEDEK.json")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                startActivityForResult(intent, REQ_CREATE_BACKUP)
            }
        }
        @JavascriptInterface fun autoBackup(json: String): Boolean {
            val uriText = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_BACKUP_URI, null) ?: return false
            return try { contentResolver.openOutputStream(Uri.parse(uriText), "wt")?.use { it.write(json.toByteArray(Charsets.UTF_8)) }; true } catch (_: Exception) { false }
        }
        @JavascriptInterface fun requestRestore() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                startActivityForResult(intent, REQ_OPEN_BACKUP)
            }
        }
        @JavascriptInterface fun hasBackupTarget(): Boolean = getSharedPreferences(PREFS, MODE_PRIVATE).contains(PREF_BACKUP_URI)
        @JavascriptInterface fun openChart(symbol: String) {
            val safe = symbol.trim().uppercase().removePrefix("BIST:").removeSuffix(".IS")
            val uri = Uri.parse("https://www.tradingview.com/chart/?symbol=BIST:${Uri.encode(safe)}")
            runOnUiThread { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        }
    }

    @Deprecated("Deprecated Android API retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri = data.data!!
        if (requestCode == REQ_CREATE_BACKUP) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
            val json = pendingBackupJson ?: "{}"
            try {
                contentResolver.openOutputStream(uri, "wt")?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_BACKUP_URI, uri.toString()).apply()
                webView.evaluateJavascript("window.MSSP_APP && window.MSSP_APP.backupResult(true);", null)
            } catch (_: Exception) { webView.evaluateJavascript("window.MSSP_APP && window.MSSP_APP.backupResult(false);", null) }
            finally { pendingBackupJson = null }
        } else if (requestCode == REQ_OPEN_BACKUP) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            try {
                val json = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "{}"
                webView.evaluateJavascript("window.MSSP_APP && window.MSSP_APP.restoreFromBackup(${JSONObject.quote(json)});", null)
            } catch (_: Exception) { webView.evaluateJavascript("window.MSSP_APP && window.MSSP_APP.restoreFromBackup('');", null) }
        }
    }

    override fun onDestroy() {
        executor.shutdownNow(); webView.destroy(); super.onDestroy()
    }
}
