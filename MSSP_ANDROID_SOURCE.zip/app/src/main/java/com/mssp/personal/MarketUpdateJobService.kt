package com.mssp.personal

import android.app.job.JobParameters
import android.app.job.JobService
import android.net.Uri
import org.json.JSONArray
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant

class MarketUpdateJobService : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        Thread {
            try {
                val prefs = getSharedPreferences("mssp_personal", MODE_PRIVATE)
                val raw = prefs.getString("watchlist", "") ?: ""
                val list = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
                val symbols = mutableListOf<String>()
                if (list.length() == 0) {
                    symbols.addAll(listOf("THYAO","ASELS","TUPRS","GARAN","AKBNK","EREGL","ISCTR","BIMAS"))
                } else {
                    for (i in 0 until list.length()) symbols.add(list.optString(i))
                }
                symbols.distinct().take(60).forEach { rawSymbol ->
                    val s = rawSymbol.trim().uppercase().removePrefix("BIST:").removeSuffix(".IS")
                    if (s.isBlank()) return@forEach
                    val y = if (s.startsWith("^")) s else "$s.IS"
                    val url = "https://query1.finance.yahoo.com/v8/finance/chart/${Uri.encode(y)}?range=2y&interval=1d&includePrePost=false&events=div%2Csplits"
                    try {
                        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                            connectTimeout = 10000; readTimeout = 15000; requestMethod = "GET"
                            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 MSSP-Personal/1.0")
                            setRequestProperty("Accept", "application/json,text/plain,*/*")
                            setRequestProperty("Referer", "https://finance.yahoo.com/")
                        }
                        if (conn.responseCode in 200..299) {
                            val body = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                            if (body.isNotBlank()) MarketCache.write(this, s, body)
                        }
                        conn.disconnect()
                    } catch (_: Exception) {}
                    try { Thread.sleep(450) } catch (_: Exception) {}
                }
                prefs.edit().putString("last_auto_update", Instant.now().toString()).apply()
            } finally {
                jobFinished(params, false)
            }
        }.start()
        return true
    }
    override fun onStopJob(params: JobParameters?): Boolean = true
}
