package com.mssp.personal

import android.content.Context
import java.io.File

object MarketCache {
    private fun dir(ctx: Context): File = File(ctx.filesDir, "market_cache").apply { mkdirs() }
    private fun safe(symbol: String) = symbol.replace(Regex("[^A-Z0-9_^.-]"), "_")
    fun write(ctx: Context, symbol: String, payload: String) {
        File(dir(ctx), safe(symbol) + ".json").writeText(payload, Charsets.UTF_8)
    }
    fun read(ctx: Context, symbol: String): String? {
        val f = File(dir(ctx), safe(symbol) + ".json")
        return if (f.exists()) f.readText(Charsets.UTF_8) else null
    }
}
