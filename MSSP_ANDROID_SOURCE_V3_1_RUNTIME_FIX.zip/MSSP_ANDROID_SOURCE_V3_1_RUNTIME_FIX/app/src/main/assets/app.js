const state={universe:[],radar:[],broad:[],lastScan:null,mode:'adaptive',history:{},confluence:{},favorites:{},hydrating:false};
const pending=new Map();let seq=0;
window.MSSP_NATIVE={
 onUniverse(raw){try{const r=JSON.parse(raw),p=pending.get(r.requestId);if(!p)return;pending.delete(r.requestId);r.ok?p.resolve(r.payload):p.reject(new Error(r.error||'Tarama hatası'))}catch(e){console.error(e)}},
 onHistory(raw){try{const r=JSON.parse(raw),p=pending.get(r.requestId);if(!p)return;pending.delete(r.requestId);r.ok?p.resolve(r.payload):p.reject(new Error(r.error||'Geçmiş veri hatası'))}catch(e){console.error(e)}}
};
function toast(t){const e=document.getElementById('toast');e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),2200)}
function fmt(v,d=2){return Number.isFinite(+v)?Number(v).toLocaleString('tr-TR',{minimumFractionDigits:d,maximumFractionDigits:d}):'—'}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function fetchUniverse(){return new Promise((resolve,reject)=>{if(typeof Android==='undefined')return reject(new Error('Android veri köprüsü yok'));const id='u'+(++seq);pending.set(id,{resolve,reject});Android.requestUniverse(id);setTimeout(()=>{if(pending.has(id)){pending.delete(id);reject(new Error('Tarama zaman aşımı'))}},35000)})}
function fetchHistory(s){return new Promise((resolve,reject)=>{const id='h'+(++seq);pending.set(id,{resolve,reject});Android.requestHistory(s,'2y','1d',id);setTimeout(()=>{if(pending.has(id)){pending.delete(id);reject(new Error('Geçmiş veri zaman aşımı'))}},25000)})}
function finalCandidateScore(x){
  const c=state.confluence[x.symbol];
  const base=Math.max(0,Math.min(100,
    (+x.radarScore||0)*.34+
    (+x.ops||0)*.18+
    (+x.confidenceScore||0)*.16+
    (100-(+x.riskScore||0))*.12+
    (+x.score||0)*.08+
    (+x.opportunityScore||0)*.12
  ));
  if(!c)return Math.round(base*.88); // OHLCV teyidi gelmeden biraz bastır.
  const confluencePct=(c.count/c.total)*100;
  const ai=+c.aiScore||0;
  let bonus=0;
  if(c.checks?.some(z=>z.name==='5+W'&&z.on))bonus+=4;
  if(c.checks?.some(z=>z.name==='Zamansallık'&&z.on))bonus+=4;
  if(c.checks?.some(z=>z.name==='Pattern'&&z.on))bonus+=3;
  if(c.checks?.some(z=>z.name==='RSI Uyum'&&z.on))bonus+=3;
  return Math.max(0,Math.min(100,Math.round(base*.58+confluencePct*.22+ai*.20+bonus)));
}
function hardReject(x){
  if(!x)return true;
  if((+x.riskScore||0)>=76)return true;
  if((+x.change||0)>8||(+x.change||0)<-4)return true;
  if(x.actionLabel==='GEÇ KALDI')return true;
  if((+x.rsi||0)>76)return true;
  return false;
}
function selected(){
  const source=(state.broad&&state.broad.length)?state.broad:state.radar;
  const arr=source.filter(x=>!hardReject(x)).map(x=>({...x,quality:finalCandidateScore(x)}));
  // Adaptif mod: ana EMA kapısından geçmeyen hisse ancak MSSP teyidi güçlüyse listeye girebilir.
  const filtered=arr.filter(x=>{
    const c=state.confluence[x.symbol];
    const support=c?.count||0, ai=c?.aiScore||0;
    if(state.mode==='strict'){
      return x.quality>=74 && (+x.riskScore||0)<=58 &&
        (x.originalGate || support>=3 || ai>=78) &&
        (['AL++','AL+','AL','AL YAKIN'].includes(x.signal) || support>=4 || ai>=82);
    }
    // Varsayılan: güçlü/uygun. Listeyi doldurmaz; kalite eşiği vardır.
    return x.quality>=66 && (+x.riskScore||0)<=68 &&
      (x.originalGate || support>=2 || ai>=70);
  });
  return filtered.sort((a,b)=>b.quality-a.quality||
    ((state.confluence[b.symbol]?.count||0)-(state.confluence[a.symbol]?.count||0))||
    b.radarScore-a.radarScore).slice(0,10);
}
function marketHealth(){if(!state.universe.length)return{score:0,label:'VERİ YOK'};const pos=state.universe.filter(x=>+x.change>0).length/state.universe.length,accepted=state.radar.length/Math.max(1,state.universe.length),score=Math.round(pos*70+Math.min(1,accepted/.06)*30);return{score,label:score>=67?'OLUMLU':score>=52?'KARARSIZ':'ZAYIF',pos}}
function stage5w(f){const s=f?.stage;return s==='TRAIL'?'KÂR KORUMA':s==='IN_TRADE'?'BOYUN KIRILDI':s==='WAIT_NECK_BREAK'?'W2 OLUŞUM':s==='WAIT_W2_EXIT'?'ADAY':'YOK'}
function zamActive(z){return ['AL+','İZLE','AKTİF'].includes(z?.signal||z?.status)}
function computeConfluence(symbol,candles){if(!candles||candles.length<90)return null;const tech=MSSPCore.technical(candles),five=MSSP5W.replay(candles,symbol),extra=MSSPExtra.enrich(candles,tech,five,symbol);const checks=[
 {k:'ema',name:'EMA30',on:!!tech.closeAboveEma30},
 {k:'five',name:'5+W',on:['IN_TRADE','TRAIL','WAIT_NECK_BREAK'].includes(five?.stage)},
 {k:'zam',name:'Zamansallık',on:zamActive(extra.zam)},
 {k:'pat',name:'Pattern',on:extra.pattern?.status==='UYGUN'},
 {k:'rsi',name:'RSI Uyum',on:!!extra.rsi?.positive},
 {k:'ai',name:'Akıllı Analiz',on:(extra.smart?.score||0)>=72}
 ];const count=checks.filter(x=>x.on).length;let label=count>=5?'ÇOK GÜÇLÜ UYUM':count>=4?'GÜÇLÜ UYUM':count>=3?'UYUMLU':count>=2?'DESTEKLİ':'SINIRLI TEYİT';return{count,total:6,label,checks,five,extra,tech,aiScore:extra.smart?.score||0}}
async function hydrateConfluence(){
  if(state.hydrating)return;
  state.hydrating=true;
  const broadTop=[...(state.broad||[])].filter(x=>!hardReject(x))
    .sort((a,b)=>(b.broadBase||0)-(a.broadBase||0))
    .slice(0,36).map(x=>x.symbol);
  const symbols=[...new Set([...broadTop,...Object.keys(state.favorites)])].slice(0,42);
  let idx=0,done=0;
  async function worker(){
    while(idx<symbols.length){
      const s=symbols[idx++];
      try{
        const raw=await fetchHistory(s),c=MSSPCore.parseYahoo(raw);
        state.history[s]=c;
        state.confluence[s]=computeConfluence(s,c);
      }catch(e){console.warn('confluence',s,e.message)}
      done++;
      if(done%4===0){render();}
    }
  }
  try{
    await Promise.all(Array.from({length:Math.min(5,symbols.length||1)},()=>worker()));
  }finally{
    state.hydrating=false;save();render();
    if(symbols.length)toast(`MSSP teyidi tamamlandı · ${symbols.length} aday`);
  }
}
function updateFavoritesFromRadar(){for(const [s,f] of Object.entries(state.favorites)){const x=state.radar.find(r=>r.symbol===s)||state.broad.find(r=>r.symbol===s)||state.universe.find(r=>r.symbol===s);if(!x)continue;const p=+x.price||+x.close;if(!(p>0))continue;f.currentPrice=p;f.lastSeen=new Date().toISOString();f.maxPrice=Math.max(+f.maxPrice||+f.signalPrice,p);f.minPrice=Math.min(+f.minPrice||+f.signalPrice,p);const ret=(p-f.signalPrice)/f.signalPrice*100,peak=(f.maxPrice-f.signalPrice)/f.signalPrice*100;f.returnPct=ret;f.peakPct=peak;f.stopDistancePct=f.stopPrice>0?(p-f.stopPrice)/p*100:null;f.targetRemainingPct=f.targetPrice>0?(f.targetPrice-p)/p*100:null;f.status=p<=f.stopPrice?'STOP ALTINDA':p>=f.targetPrice?'HEDEFE ULAŞTI':ret>=5?'KÂRDA':ret<=-3?'GERİLEDİ':'TAKİPTE'}}
function toggleFavorite(symbol){const x=state.radar.find(r=>r.symbol===symbol)||state.broad.find(r=>r.symbol===symbol);if(state.favorites[symbol]){delete state.favorites[symbol];toast(symbol+' favorilerden çıkarıldı')}else if(x){const p=+x.price||+x.close;state.favorites[symbol]={symbol,signalAt:new Date().toISOString(),signalPrice:p,currentPrice:p,maxPrice:p,minPrice:p,stopPrice:+x.stopPrice||0,targetPrice:+x.targetPrice||0,signal:x.signal,quality:finalCandidateScore(x),status:'TAKİPTE'};toast(symbol+' takibe alındı')}save();render();hydrateConfluence()}
window.toggleFavorite=toggleFavorite;
function humanMetric(label,value,desc){return `<div><b>${label}: ${value}</b><span>${desc}</span></div>`}
function confluenceHtml(s){const c=state.confluence[s];if(!c)return `<div class="confluence"><div class="muted">MSSP teyitleri hazırlanıyor…</div></div>`;return `<div class="confluence"><div class="confluenceTop"><b>${c.label}</b><span class="confluenceScore">${c.count}/${c.total}</span></div><div class="evidence">${c.checks.map(x=>`<span class="ev ${x.on?'on':''}">${x.on?'✓':'–'} ${x.name}</span>`).join('')}</div></div>`}

function reasons(x){
  const r=[];
  if(!x)return r;

  if(x.originalGate) r.push('Ana MSSP filtresini geçti');

  if(Number.isFinite(+x.crossDaysAgo)){
    if(+x.crossDaysAgo===0) r.push('EMA30 bugün kırıldı');
    else if(+x.crossDaysAgo===1) r.push('EMA30 1 gün önce kırıldı');
    else if(+x.crossDaysAgo===2) r.push('EMA30 kırılımı yeni');
  }

  if(+x.close < +x.ema30 && Number.isFinite(+x.projectedDays) && +x.projectedDays<=2)
    r.push('EMA30 geçişi yakın');

  if(+x.relativeVolume>=1.5) r.push('Hacim güçlü');
  else if(+x.relativeVolume>=1.0) r.push('Hacim destekli');

  if(+x.adx>=25) r.push('Trend gücü yüksek');
  else if(+x.adx>=18) r.push('Trend güçleniyor');

  if(+x.rsi>=48 && +x.rsi<=68) r.push('RSI sağlıklı bölgede');

  if(+x.ess>=65) r.push('Fiyat/EMA sıkışması iyi');
  if(+x.ema30SlopePercent5d>=0) r.push('EMA30 eğimi pozitif');
  if(+x.firstMoveScore>=9) r.push('Hareket geç kalmamış');

  const c=state.confluence[x.symbol];
  if(c){
    for(const z of c.checks||[]){
      if(z.on && z.name!=='EMA30') r.push(z.name+' teyidi');
    }
  }

  return [...new Set(r)].slice(0,7);
}

function render(){updateFavoritesFromRadar();const picks=selected(),m=marketHealth();document.getElementById('marketLabel').textContent=m.label;document.getElementById('marketLabel').className='marketLabel '+(m.label==='OLUMLU'?'up':m.label==='ZAYIF'?'down':'');document.getElementById('marketText').textContent=state.universe.length?`BIST pozitif oranı %${Math.round(m.pos*100)} · Geniş havuz ${state.broad?.length||0} · Final ${picks.length}`:'BIST taraması bekleniyor.';document.getElementById('statUniverse').textContent=state.universe.length||'—';document.getElementById('statRadar').textContent=(state.broad?.length||state.radar.length||'—');document.getElementById('statStrong').textContent=picks.length;document.getElementById('statTime').textContent=state.lastScan?new Date(state.lastScan).toLocaleTimeString('tr-TR',{hour:'2-digit',minute:'2-digit'}):'—';document.getElementById('statusText').textContent=state.lastScan?'GÜNCEL':'BEKLİYOR';document.getElementById('listNote').textContent=state.mode==='strict'?'Çok seçici: birleşik skor ≥74. Tüm MSSP teyitleri seçimden ÖNCE hesaplanır.':'Adaptif seçim: geniş aday havuzu + 5+W + Zamansallık + Pattern + RSI + Akıllı Analiz. Zayıf hisseyle liste doldurulmaz.';
 const list=document.getElementById('list');if(!picks.length)list.innerHTML=`<div class="empty"><b>Bugün katı kriterlere uyan aday yok.</b><span class="muted">Listeyi doldurmak için zayıf hisse eklenmedi.</span></div>`;else list.innerHTML=picks.map((x,i)=>{const rr=(x.targetPrice>x.price&&x.price>x.stopPrice)?((x.targetPrice-x.price)/(x.price-x.stopPrice)):null,rs=reasons(x),fav=!!state.favorites[x.symbol];return `<article class="pick"><div class="pickTop"><div><div class="symbol">${i+1}. ${esc(x.symbol)}</div><div class="company">${esc(x.name||'')}</div><span class="tag">${x.signal}</span> <span class="tag blue">${esc(x.actionLabel)}</span></div><div><div class="price">${fmt(x.price)}</div><div class="change ${x.change>=0?'up':'down'}">${x.change>=0?'▲':'▼'} %${fmt(Math.abs(x.change),2)}</div><button class="favBtn ${fav?'on':''}" onclick="toggleFavorite('${x.symbol}')">${fav?'★ Takipte':'☆ Favoriye Al'}</button></div></div><div class="scoreLine"><span>SEÇİM SKORU</span><div class="bar"><i style="width:${x.quality}%"></i></div><b>${x.quality}</b></div>${confluenceHtml(x.symbol)}<div class="levels"><div class="level"><span>GİRİŞ</span><b>${fmt(x.price)}</b></div><div class="level stop"><span>STOP</span><b>${fmt(x.stopPrice)}</b></div><div class="level target"><span>HEDEF</span><b>${fmt(x.targetPrice)}</b></div></div><div class="metrics"><div class="metric"><span>Fırsat</span><b>${fmt(x.radarScore,0)}</b></div><div class="metric"><span>Kalite</span><b>${fmt(x.ops,0)}</b></div><div class="metric"><span>Güven</span><b>${fmt(x.confidenceScore,0)}</b></div><div class="metric"><span>Risk</span><b>${fmt(x.riskScore,0)}</b></div><div class="metric"><span>RSI</span><b>${fmt(x.rsi,1)}</b></div><div class="metric"><span>Trend Gücü</span><b>${fmt(x.adx,1)}</b></div><div class="metric"><span>Hacim</span><b>${fmt(x.relativeVolume,2)}x</b></div><div class="metric"><span>Risk/Getiri</span><b>${rr?fmt(rr,2):'—'}</b></div></div><div class="reason">${rs.map(r=>`<span class="chip">${esc(r)}</span>`).join('')}</div><div class="explain">${humanMetric('Fırsat Kalitesi',fmt(x.radarScore,0),'Genel MSSP uygunluk puanı.')}${humanMetric('Teknik Kalite',fmt(x.ops,0),'EMA yakınlığı, sıkışma ve teknik güç birleşimi.')}${humanMetric('Güven',fmt(x.confidenceScore,0),'Sinyalin teyit edilme derecesi.')}${humanMetric('Risk',fmt(x.riskScore,0),'Düşük olması daha iyidir.')}</div><div style="margin-top:10px;text-align:right"><button class="secondary" onclick="Android.openChart('${esc(x.symbol)}')">📈 Grafik</button></div></article>`}).join('');renderFavorites()}
function renderFavorites(){const box=document.getElementById('favorites'),arr=Object.values(state.favorites).sort((a,b)=>new Date(b.signalAt)-new Date(a.signalAt));document.getElementById('favoriteCount').textContent=arr.length;if(!arr.length){box.innerHTML='<div class="empty"><b>Henüz takipte hisse yok.</b><span class="muted">Ana listeden ☆ Favoriye Al ile ekleyebilirsin.</span></div>';return}box.innerHTML=arr.map(f=>{const c=state.confluence[f.symbol],ret=+f.returnPct||0,peak=+f.peakPct||0;return `<article class="favCard"><div class="favTop"><div><div class="symbol">${f.symbol}</div><div class="muted">Sinyal: ${new Date(f.signalAt).toLocaleString('tr-TR')} · ${f.signal}</div></div><div><div class="favPerf ${ret>=0?'up':'down'}">${ret>=0?'+':''}%${fmt(ret,2)}</div><button class="favBtn on" onclick="toggleFavorite('${f.symbol}')">★ Takipten Çıkar</button></div></div><div class="favInfo"><div><span>Sinyal Fiyatı</span><b>${fmt(f.signalPrice)}</b></div><div><span>Güncel</span><b>${fmt(f.currentPrice)}</b></div><div><span>En İyi</span><b class="up">+%${fmt(peak,2)}</b></div><div><span>Durum</span><b>${f.status}</b></div><div><span>Stop</span><b>${fmt(f.stopPrice)}</b></div><div><span>Stopa Mesafe</span><b>${fmt(f.stopDistancePct)}%</b></div><div><span>Hedef</span><b>${fmt(f.targetPrice)}</b></div><div><span>Hedefe Kalan</span><b>${fmt(f.targetRemainingPct)}%</b></div></div>${confluenceHtml(f.symbol)}<div style="margin-top:10px;text-align:right"><button class="secondary" onclick="Android.openChart('${f.symbol}')">📈 Grafik</button></div></article>`}).join('')}
async function scan(show=true){
  if(show)toast('BIST taranıyor…');
  document.getElementById('statusText').textContent='TARANIYOR';

  let res;
  try{
    const raw=await fetchUniverse();
    res=MSSPRadarParity.scan(raw);
  }catch(e){
    document.getElementById('statusText').textContent='VERİ HATASI';
    toast('Veri taraması başarısız: '+e.message);
    return;
  }

  state.universe=res.all||[];
  state.radar=res.results||[];
  state.broad=res.broad||res.results||[];
  state.lastScan=new Date().toISOString();
  updateFavoritesFromRadar();
  save();

  try{
    render();
    document.getElementById('statusText').textContent='GÜNCEL';
  }catch(e){
    console.error('UI render hatası',e);
    document.getElementById('statusText').textContent='EKRAN HATASI';
    toast('Ekran çizim hatası: '+e.message);
    return;
  }

  if(show)toast(`${state.universe.length} hisse · ${state.broad.length} geniş aday; MSSP teyitleri hesaplanıyor`);
  hydrateConfluence();
}
function save(){localStorage.setItem('mssp_one_list_v2',JSON.stringify({universe:state.universe,radar:state.radar,broad:state.broad,lastScan:state.lastScan,mode:state.mode,favorites:state.favorites}))}
function load(){try{const s=JSON.parse(localStorage.getItem('mssp_one_list_v2')||localStorage.getItem('mssp_one_list_state')||'{}');if(Array.isArray(s.universe))state.universe=s.universe;if(Array.isArray(s.radar))state.radar=s.radar;if(Array.isArray(s.broad))state.broad=s.broad;if(s.lastScan)state.lastScan=s.lastScan;if(s.mode)state.mode=(s.mode==='normal'?'adaptive':s.mode);if(s.favorites&&typeof s.favorites==='object')state.favorites=s.favorites}catch(_){}document.getElementById('mode').value=state.mode;render();scan(false)}
function backupJson(){return JSON.stringify({schema:'MSSP_ONE_LIST_V3_ADAPTIVE',createdAt:new Date().toISOString(),state:{universe:state.universe,radar:state.radar,broad:state.broad,lastScan:state.lastScan,mode:state.mode,favorites:state.favorites}})}
window.MSSP_APP={backupResult(ok){toast(ok?'Yedek hedefi kaydedildi':'Yedek kaydedilemedi')},restoreFromBackup(raw){try{const b=JSON.parse(raw);if(b?.state?.favorites)state.favorites=b.state.favorites;if(b?.state?.mode)state.mode=b.state.mode;save();render();toast('Yedek geri yüklendi')}catch(_){toast('Yedek okunamadı')}}};
document.getElementById('refreshBtn').onclick=()=>scan(true);document.getElementById('mode').onchange=e=>{state.mode=e.target.value;save();render();hydrateConfluence()};document.getElementById('backupBtn').onclick=()=>{try{Android.requestBackup(backupJson())}catch(_){toast('Yedek açılamadı')}};document.getElementById('backupNowBtn').onclick=()=>{try{toast(Android.autoBackup(backupJson())?'Drive yedeği güncellendi':'Önce yedek hedefi seç')}catch(_){toast('Yedek başarısız')}};load();